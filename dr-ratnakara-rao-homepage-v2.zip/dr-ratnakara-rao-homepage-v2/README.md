# Dr. Gogineni Ratnakara Rao — Homepage v2

Refined homepage with:
- premium navy/teal/gold medical design
- stronger hero hierarchy
- supplied doctor photograph
- academic credential strip
- separate clinic/Apollo appointment cards
- conditions grid
- specialist-care section
- final appointment CTA
- responsive mobile navigation and persistent mobile actions

The new Hyderabad clinic card intentionally does not invent an address, timing, or booking route.
